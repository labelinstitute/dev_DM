# -*- coding: utf-8 -*-
from __future__ import division

import random

from otree.common import Currency as c, currency_range

from ._builtin import Bot
from .models import Constants
from . import pages


class PlayerBot(Bot):

    def play_round(self):

        self.submit(pages.Introduction)

        self.submit(
            pages.Question,
            {'training_question_1': 'Alice gets 300 points, Bob gets 0 points'}
        )

        self.submit(pages.Feedback1)

        self.submit(
            pages.Decision,
            {"decision": random.choice(['Cooperate', 'Defect'])}
        )

        self.submit(pages.Results)

    def validate_play(self):
        pass
