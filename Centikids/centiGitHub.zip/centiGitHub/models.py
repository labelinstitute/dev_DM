import random
import itertools

from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)
import json
import random

author = "ccrabbe@gmail.com"

doc = """
A graphical version of the centipede game
"""


class Constants(BaseConstants):
    name_in_url = 'cti3'
    players_per_group = 2
    num_rounds = 5

    blue_player = 'blue'
    orange_player = 'orange'

class Subsession(BaseSubsession):
    stop_payoffs = models.StringField(initial='')
    other_payoffs = models.StringField(initial='')
    max_rounds = models.IntegerField(initial=Constants.num_rounds)
    your_points = models.StringField()
    your_turn = models.StringField()
    others_turn = models.StringField()
    num_stages = models.IntegerField()
    exchange_rate = models.FloatField(initial=1.0)

    def creating_session(self):

        # print("groups at start of centi2: " + str(self.get_group_matrix()))
        if self.round_number == 1:
            if 'centi_group_matrix' in self.session.vars:
                old_matrix = self.session.vars['centi_group_matrix']
                new_matrix = self.get_group_matrix().copy()
                matrix_to_set = self.get_group_matrix().copy()

                id_to_player = {}
                for ni in range(len(new_matrix)):
                    for nj in range(len(new_matrix[ni])):
                        id_to_player[new_matrix[ni][nj].participant.id_in_session] = new_matrix[ni][nj]

                for i in range(len(old_matrix)):
                    for j in range(len(old_matrix[i])):
                        old_id = old_matrix[i][j].participant.id_in_session
                        # print("trying to get new player with id=" + str(old_id) + ", i=" + str(i) + ", j=" + str(j))
                        # now look through the new metrix for this id
                        matrix_to_set[i][j] = id_to_player[old_id]
                        # print("matrix_to_set="+str(matrix_to_set))
                        # print("new_matrix="+str(new_matrix))
                print("new matrix in centi3: " + str(matrix_to_set))
                self.set_group_matrix(matrix_to_set)
            else:
                self.group_randomly()
        else:
            self.group_like_round(self.round_number-1)
        self.group_randomly(fixed_id_in_group=True)
        print("shuffled groups but maintained roles.  new matrix: " + str(self.get_group_matrix()))


        if 'c3_stop_payoffs' in self.session.config:
            self.stop_payoffs = self.session.config['c3_stop_payoffs']
        if 'c3_other_payoffs' in self.session.config:
            self.other_payoffs = self.session.config['c3_other_payoffs']
        if 'c3_max_rounds' in self.session.config:
            self.max_rounds = self.session.config['c3_max_rounds']
        if 'c3_your_turn' in self.session.config:
            self.your_turn = self.session.config['c3_your_turn']
        if 'c3_your_points' in self.session.config:
            self.your_points = self.session.config['c3_your_points']
        if 'c3_others_turn' in self.session.config:
            self.others_turn = self.session.config['c3_others_turn']
        if 'c3_num_stages' in self.session.config:
            self.num_stages = self.session.config['c3_num_stages']
        if 'c3_exchange_rate' in self.session.config:
            self.exchange_rate = self.session.config['c3_exchange_rate']

        for p in self.get_players():
            self.session.vars['{}-c3_total_payoffs'.format(p.participant.id_in_session)] = 0.0
            self.session.vars['{}-c3_num_rounds'.format(p.participant.id_in_session)] = self.max_rounds


class Group(BaseGroup):
    ejected = models.BooleanField(initial=False)

    def set_payoffs(self, stopnum):
        self.session.vars['group.'+str(self.id_in_subsession)+'.stopnum'] = stopnum
        
        for p in self.get_players():
            self.session.vars['{}-c3_decision1_round_{}'.format(p.participant.id_in_session,
                                                                self.subsession.round_number)] = p.decision1
            self.session.vars['{}-c3_decision2_round_{}'.format(p.participant.id_in_session,
                                                                self.subsession.round_number)] = p.decision2
            self.session.vars['{}-c3_decision3_round_{}'.format(p.participant.id_in_session,
                                                                self.subsession.round_number)] = p.decision3
            self.session.vars['{}-c3_decision4_round_{}'.format(p.participant.id_in_session,
                                                                self.subsession.round_number)] = p.decision4
            self.session.vars['{}-c3_decision5_round_{}'.format(p.participant.id_in_session,
                                                                self.subsession.round_number)] = p.decision5
            self.session.vars['{}-c3_decision6_round_{}'.format(p.participant.id_in_session,
                                                                self.subsession.round_number)] = p.decision6
            self.session.vars['{}-c3_decision7_round_{}'.format(p.participant.id_in_session,
                                                                self.subsession.round_number)] = p.decision7
            self.session.vars['{}-c3_decision8_round_{}'.format(p.participant.id_in_session,
                                                                self.subsession.round_number)] = p.decision8
            self.session.vars['{}-c3_decision9_round_{}'.format(p.participant.id_in_session,
                                                                self.subsession.round_number)] = p.decision9
            self.session.vars['{}-c3_decision10_round_{}'.format(p.participant.id_in_session,
                                                                self.subsession.round_number)] = p.decision10
            self.session.vars['{}-c3_decision11_round_{}'.format(p.participant.id_in_session,
                                                                self.subsession.round_number)] = p.decision11
            self.session.vars['{}-c3_decision12_round_{}'.format(p.participant.id_in_session,
                                                                self.subsession.round_number)] = p.decision12
            self.session.vars['{}-c3_role_round_{}'.format(p.participant.id_in_session,
                                                                self.subsession.round_number)] = p.role()
            self.session.vars['{}-c3_group_round_{}'.format(p.participant.id_in_session,
                                                           self.subsession.round_number)] = p.group.id_in_subsession

        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        print("stops["+str(stopnum-1)+"]="+str(stops[stopnum-1])+", int(stops["+str(stopnum-1)+"]="+str(int(stops[stopnum-1])))
        print("exchanged="+str(int(stops[stopnum-1])*self.subsession.exchange_rate))
        if stopnum % 2 == 1:
            self.get_player_by_role(Constants.blue_player).payoff = int(stops[stopnum-1])
            self.get_player_by_role(Constants.orange_player).payoff = int(others[stopnum - 1])
        else:
            self.get_player_by_role(Constants.orange_player).payoff = int(stops[stopnum - 1])
            self.get_player_by_role(Constants.blue_player).payoff = int(others[stopnum - 1])
        for p in self.get_players():
            self.session.vars['{}-c3_total_payoffs'.format(p.participant.id_in_session)] += p.payoff
            p.payoff_unexchanged = int(p.payoff)
            self.session.vars['{}-c3_points_round_{}'.format(p.participant.id_in_session,
                                                             self.subsession.round_number)] = p.payoff_unexchanged
            p.payoff = p.payoff * self.subsession.exchange_rate
            p.save()

class Player(BasePlayer):
    decision1 = models.StringField(label="")
    decision2 = models.StringField(label="")
    decision3 = models.StringField(label="")
    decision4 = models.StringField(label="")
    decision5 = models.StringField(label="")
    decision6 = models.StringField(label="")
    decision7 = models.StringField(label="")
    decision8 = models.StringField(label="")
    decision9 = models.StringField(label="")
    decision10 = models.StringField(label="")
    decision11 = models.StringField(label="")
    decision12 = models.StringField(label="")
    payoff_unexchanged = models.IntegerField()

    def role(self):
        # print("player.role() called, self.id_in_group=" + str(self.id_in_group)+", round_number="+str(self.subsession.round_number))
        if self.id_in_group == (self.subsession.round_number%2)+1:
            # print("player.role() called, self.id_in_group=" + str(self.id_in_group)+", role=ROW")
            return Constants.blue_player
        else:
            # print("player.role() called, self.id_in_group=" + str(self.id_in_group) + ", role=COLUMN")
            return Constants.orange_player

    def other_player(self):
        other = self.group.get_player_by_id((self.id_in_group)%Constants.players_per_group+1)
        print("player.other_player() called.  id_in_group="+str(self.id_in_group)+", returning "+str(other))
        return other
