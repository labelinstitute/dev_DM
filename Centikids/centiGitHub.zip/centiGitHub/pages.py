# -*- coding: utf-8 -*-
from __future__ import division
from . import models
from ._builtin import Page, WaitPage
from .models import Constants
import decimal



class Decision1(Page):
    form_model = 'player'
    form_fields = ['decision1']
    template_name = 'centi/Decision.html'

    def is_displayed(self):
        return self.player.role() == Constants.blue_player and not self.group.ejected and self.subsession.num_stages >= 1 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):

        vars = {
            'role': self.player.role(),
            'decision_stage': 1,
            'num_stages': self.subsession.num_stages,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i%2==0:
                vars['blue_{}'.format(i)]=stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

    # def before_next_page(self):
    #     if self.player.decision1 == 'stop':
    #         self.group.ejected = True
    #         self.group.set_payoffs(1)
    #         self.group.save()

class Decision2(Page):
    form_model = 'player'
    form_fields = ['decision2']
    template_name = 'centi/Decision.html'

    def is_displayed(self):
        print("self.group.ejected=="+str(self.group.ejected))
        return self.player.role() == Constants.orange_player and not self.group.ejected and self.subsession.num_stages >= 2  and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):

        vars = {
            'role': self.player.role(),
            'decision_stage': 2,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

    # def before_next_page(self):
    #     if self.player.decision2 == 'stop':
    #         self.group.ejected = True
    #         self.group.set_payoffs(2)
    #         self.group.save()


class Decision3(Page):
    form_model = 'player'
    form_fields = ['decision3']
    template_name = 'centi/Decision.html'

    def is_displayed(self):
        return self.player.role() == Constants.blue_player and not self.group.ejected and self.subsession.num_stages >= 3 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):

        vars = {
            'role': self.player.role(),
            'decision_stage': 3,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

    # def before_next_page(self):
    #     if self.player.decision3 == 'stop':
    #         self.group.ejected = True
    #         self.group.set_payoffs(3)
    #         self.group.save()

class Decision4(Page):
    form_model = 'player'
    form_fields = ['decision4']
    template_name = 'centi/Decision.html'

    def is_displayed(self):
        return self.player.role() == Constants.orange_player and not self.group.ejected and self.subsession.num_stages >= 4 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):

        vars = {
            'role': self.player.role(),
            'decision_stage': 4,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

    # def before_next_page(self):
    #     if self.player.decision4 == 'stop':
    #         self.group.ejected = True
    #         self.group.set_payoffs(4)
    #         self.group.save()

class Decision5(Page):
    form_model = 'player'
    form_fields = ['decision5']
    template_name = 'centi/Decision.html'

    def is_displayed(self):
        return self.player.role() == Constants.blue_player and not self.group.ejected and self.subsession.num_stages >= 5 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):

        vars = {
            'role': self.player.role(),
            'decision_stage': 5,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

    # def before_next_page(self):
    #     if self.player.decision5 == 'stop':
    #         self.group.ejected = True
    #         self.group.set_payoffs(5)
    #         self.group.save()

class Decision6(Page):
    form_model = 'player'
    form_fields = ['decision6']
    template_name = 'centi/Decision.html'

    def is_displayed(self):
        return self.player.role() == Constants.orange_player and not self.group.ejected and self.subsession.num_stages >= 6 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):

        vars = {
            'role': self.player.role(),
            'decision_stage': 6,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

    # def before_next_page(self):
    #     if self.player.decision6 == 'stop':
    #         self.group.ejected = True
    #         self.group.set_payoffs(6)
    #         self.group.save()

class Decision7(Page):
    form_model = 'player'
    form_fields = ['decision7']
    template_name = 'centi/Decision.html'

    def is_displayed(self):
        return self.player.role() == Constants.blue_player and not self.group.ejected and self.subsession.num_stages >= 7 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):

        vars = {
            'role': self.player.role(),
            'decision_stage': 7,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

    # def before_next_page(self):
    #     if self.player.decision7 == 'stop':
    #         self.group.ejected = True
    #         self.group.set_payoffs(7)
    #         self.group.save()

class Decision8(Page):
    form_model = 'player'
    form_fields = ['decision8']
    template_name = 'centi/Decision.html'

    def is_displayed(self):
        return self.player.role() == Constants.orange_player and not self.group.ejected and self.subsession.num_stages >= 8 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):

        vars = {
            'role': self.player.role(),
            'decision_stage': 8,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

    # def before_next_page(self):
    #     if self.player.decision8 == 'stop':
    #         self.group.ejected = True
    #         self.group.set_payoffs(8)
    #         self.group.save()

class Decision9(Page):
    form_model = 'player'
    form_fields = ['decision9']
    template_name = 'centi/Decision.html'

    def is_displayed(self):
        return self.player.role() == Constants.blue_player and not self.group.ejected and self.subsession.num_stages >= 9 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):

        vars = {
            'role': self.player.role(),
            'decision_stage': 9,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

    # def before_next_page(self):
    #     if self.player.decision9 == 'stop':
    #         self.group.ejected = True
    #         self.group.set_payoffs(9)
    #         self.group.save()

class Decision10(Page):
    form_model = 'player'
    form_fields = ['decision10']
    template_name = 'centi/Decision.html'

    def is_displayed(self):
        return self.player.role() == Constants.orange_player and not self.group.ejected and self.subsession.num_stages >= 10 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):

        vars = {
            'role': self.player.role(),
            'decision_stage': 10,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

    # def before_next_page(self):
    #     if self.player.decision10 == 'stop':
    #         self.group.ejected = True
    #         self.group.set_payoffs(10)
    #         self.group.save()

class Decision11(Page):
    form_model = 'player'
    form_fields = ['decision11']
    template_name = 'centi/Decision.html'

    def is_displayed(self):
        return self.player.role() == Constants.blue_player and not self.group.ejected and self.subsession.num_stages >= 11 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):

        vars = {
            'role': self.player.role(),
            'decision_stage': 11,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

    # def before_next_page(self):
    #     if self.player.decision11 == 'stop':
    #         self.group.ejected = True
    #         self.group.set_payoffs(11)
    #         self.group.save()

class Decision12(Page):
    form_model = 'player'
    form_fields = ['decision12']
    template_name = 'centi/Decision.html'

    def is_displayed(self):
        return self.player.role() == Constants.orange_player and not self.group.ejected and self.subsession.num_stages >= 12 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):

        vars = {
            'role': self.player.role(),
            'decision_stage': 12,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

    # def before_next_page(self):
    #     if self.player.decision12 == 'stop':
    #         self.group.ejected = True
    #         self.group.set_payoffs(12)
    #         self.group.save()


class ResultsWait(WaitPage):
    template_name = 'centi/DecisionWait.html'
    wait_for_all_groups = True

    def is_displayed(self):
        return self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):
        vars = {
            'role': self.player.role(),
            'decision_stage': self.subsession.num_stages + 1,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

class Results(Page):
    form_model = 'player'
    form_fields = []

    def is_displayed(self):
        return self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):

        vars = {
            'role': self.player.role(),
            'decision_stage': self.session.vars['group.'+str(self.group.id_in_subsession)+'.stopnum'],
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

class Decision1Wait(WaitPage):
    template_name = 'centi/DecisionWait.html'

    def after_all_players_arrive(self):
        op = self.group.get_player_by_role(Constants.orange_player)
        bp = self.group.get_player_by_role(Constants.blue_player)
        if (bp.decision1 and bp.decision1 == 'stop') or (op.decision1 and op.decision1 == 'stop'):
            self.group.ejected = True
            self.group.set_payoffs(1)

    def is_displayed(self):
        return not self.group.ejected and self.subsession.num_stages >= 1 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):
        vars = {
            'role': self.player.role(),
            'decision_stage': 1,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

class Decision2Wait(WaitPage):
    template_name = 'centi/DecisionWait.html'

    def after_all_players_arrive(self):
        op = self.group.get_player_by_role(Constants.orange_player)
        bp = self.group.get_player_by_role(Constants.blue_player)
        if (bp.decision2 and bp.decision2 == 'stop') or (op.decision2 and op.decision2 == 'stop'):
            self.group.ejected = True
            self.group.set_payoffs(2)

    def is_displayed(self):
        return not self.group.ejected and self.subsession.num_stages >= 2 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):
        vars = {
            'role': self.player.role(),
            'decision_stage': 2,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

class Decision3Wait(WaitPage):
    template_name = 'centi/DecisionWait.html'

    def after_all_players_arrive(self):
        op = self.group.get_player_by_role(Constants.orange_player)
        bp = self.group.get_player_by_role(Constants.blue_player)
        if (bp.decision3 and bp.decision3 == 'stop') or (op.decision3 and op.decision3 == 'stop'):
            self.group.ejected = True
            self.group.set_payoffs(3)

    def is_displayed(self):
        return not self.group.ejected and self.subsession.num_stages >= 3 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):
        vars = {
            'role': self.player.role(),
            'decision_stage': 3,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

class Decision4Wait(WaitPage):
    template_name = 'centi/DecisionWait.html'

    def after_all_players_arrive(self):
        op = self.group.get_player_by_role(Constants.orange_player)
        bp = self.group.get_player_by_role(Constants.blue_player)
        if (bp.decision4 and bp.decision4 == 'stop') or (op.decision4 and op.decision4 == 'stop'):
            self.group.ejected = True
            self.group.set_payoffs(4)

    def is_displayed(self):
        return not self.group.ejected and self.subsession.num_stages >= 4 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):
        vars = {
            'role': self.player.role(),
            'decision_stage': 4,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

class Decision5Wait(WaitPage):
    template_name = 'centi/DecisionWait.html'

    def after_all_players_arrive(self):
        op = self.group.get_player_by_role(Constants.orange_player)
        bp = self.group.get_player_by_role(Constants.blue_player)
        if (bp.decision5 and bp.decision5 == 'stop') or (op.decision5 and op.decision5 == 'stop'):
            self.group.ejected = True
            self.group.set_payoffs(5)

    def is_displayed(self):
        return not self.group.ejected and self.subsession.num_stages >= 5 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):
        vars = {
            'role': self.player.role(),
            'decision_stage': 5,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

class Decision6Wait(WaitPage):
    template_name = 'centi/DecisionWait.html'

    def after_all_players_arrive(self):
        op = self.group.get_player_by_role(Constants.orange_player)
        bp = self.group.get_player_by_role(Constants.blue_player)
        if (bp.decision6 and bp.decision6 == 'stop') or (op.decision6 and op.decision6 == 'stop'):
            self.group.ejected = True
            self.group.set_payoffs(6)

    def is_displayed(self):
        return not self.group.ejected and self.subsession.num_stages >= 6 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):
        vars = {
            'role': self.player.role(),
            'decision_stage': 6,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

class Decision7Wait(WaitPage):
    template_name = 'centi/DecisionWait.html'

    def after_all_players_arrive(self):
        op = self.group.get_player_by_role(Constants.orange_player)
        bp = self.group.get_player_by_role(Constants.blue_player)
        if (bp.decision7 and bp.decision7 == 'stop') or (op.decision7 and op.decision7 == 'stop'):
            self.group.ejected = True
            self.group.set_payoffs(7)

    def is_displayed(self):
        return not self.group.ejected and self.subsession.num_stages >= 7 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):
        vars = {
            'role': self.player.role(),
            'decision_stage': 7,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

class Decision8Wait(WaitPage):
    template_name = 'centi/DecisionWait.html'

    def after_all_players_arrive(self):
        op = self.group.get_player_by_role(Constants.orange_player)
        bp = self.group.get_player_by_role(Constants.blue_player)
        if (bp.decision8 and bp.decision8 == 'stop') or (op.decision8 and op.decision8 == 'stop'):
            self.group.ejected = True
            self.group.set_payoffs(8)

    def is_displayed(self):
        return not self.group.ejected and self.subsession.num_stages >= 8 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):
        vars = {
            'role': self.player.role(),
            'decision_stage': 8,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

class Decision9Wait(WaitPage):
    template_name = 'centi/DecisionWait.html'

    def after_all_players_arrive(self):
        op = self.group.get_player_by_role(Constants.orange_player)
        bp = self.group.get_player_by_role(Constants.blue_player)
        if (bp.decision9 and bp.decision9 == 'stop') or (op.decision9 and op.decision9 == 'stop'):
            self.group.ejected = True
            self.group.set_payoffs(9)

    def is_displayed(self):
        return not self.group.ejected and self.subsession.num_stages >= 9 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):
        vars = {
            'role': self.player.role(),
            'decision_stage': 9,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

class Decision10Wait(WaitPage):
    template_name = 'centi/DecisionWait.html'

    def after_all_players_arrive(self):
        op = self.group.get_player_by_role(Constants.orange_player)
        bp = self.group.get_player_by_role(Constants.blue_player)
        if (bp.decision10 and bp.decision10 == 'stop') or (op.decision10 and op.decision10 == 'stop'):
            self.group.ejected = True
            self.group.set_payoffs(10)

    def is_displayed(self):
        return not self.group.ejected and self.subsession.num_stages >= 10 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):
        vars = {
            'role': self.player.role(),
            'decision_stage': 10,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

class Decision11Wait(WaitPage):
    template_name = 'centi/DecisionWait.html'

    def after_all_players_arrive(self):
        op = self.group.get_player_by_role(Constants.orange_player)
        bp = self.group.get_player_by_role(Constants.blue_player)
        if (bp.decision11 and bp.decision11 == 'stop') or (op.decision11 and op.decision11 == 'stop'):
            self.group.ejected = True
            self.group.set_payoffs(11)

    def is_displayed(self):
        return not self.group.ejected and self.subsession.num_stages >= 11 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):
        vars = {
            'role': self.player.role(),
            'decision_stage': 11,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars

class Decision12Wait(WaitPage):
    template_name = 'centi/DecisionWait.html'

    def after_all_players_arrive(self):
        op = self.group.get_player_by_role(Constants.orange_player)
        bp = self.group.get_player_by_role(Constants.blue_player)
        if (bp.decision12 and bp.decision12 == 'stop') or (op.decision12 and op.decision12 == 'stop'):
            self.group.ejected = True
            self.group.set_payoffs(12)

    def is_displayed(self):
        return not self.group.ejected and self.subsession.num_stages >= 12 and self.subsession.round_number <= self.subsession.max_rounds

    def vars_for_template(self):
        vars = {
            'role': self.player.role(),
            'decision_stage': 12,
        }
        stops = self.subsession.stop_payoffs.split(',')
        others = self.subsession.other_payoffs.split(',')
        # print("len(stops)="+str(len(stops)))
        for i in range(len(stops)):
            if i % 2 == 0:
                vars['blue_{}'.format(i)] = stops[i]
                vars['orange_{}'.format(i)] = others[i]
            else:
                vars['blue_{}'.format(i)] = others[i]
                vars['orange_{}'.format(i)] = stops[i]

        return vars


class Wait(Page):
    form_model='player'
    form_fields=[]

    def is_displayed(self):
        return self.subsession.round_number == self.subsession.max_rounds

page_sequence = [
    Decision1, Decision1Wait,
    Decision2, Decision2Wait,
    Decision3, Decision3Wait,
    Decision4, Decision4Wait,
    Decision5, Decision5Wait,
    Decision6, Decision6Wait,
    Decision7, Decision7Wait,
    Decision8, Decision8Wait,
    Decision9, Decision9Wait,
    Decision10, Decision10Wait,
    Decision11, Decision11Wait,
    Decision12, Decision12Wait,
    ResultsWait, Results, Wait,
]
