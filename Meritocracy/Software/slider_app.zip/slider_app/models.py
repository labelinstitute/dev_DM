import random
import itertools
from random import randint
from otree.db.models import ForeignKey, Model

from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)
import json
import random

author = "ccrabbe@gmail.com"

doc = """
A real-effort sliders task (modified from https://github.com/chkgk/slider_task)
"""


class Constants(BaseConstants):
    name_in_url = 'slt'
    players_per_group = None
    num_rounds = 1


class Subsession(BaseSubsession):
    num_training_sliders = models.IntegerField(initial=2)
    num_sliders = models.IntegerField(initial=5)
    num_slider_columns = models.IntegerField(initial=1)
    timeout_seconds = models.IntegerField(initial=10)

    def creating_session(self):
        self.group_randomly()

        if 'sliders_num_training_sliders' in self.session.config:
            self.num_training_sliders = self.session.config['sliders_num_training_sliders']
        if 'sliders_num_sliders' in self.session.config:
            self.num_sliders = self.session.config['sliders_num_sliders']
        if 'sliders_num_columns' in self.session.config:
            self.num_slider_columns = self.session.config['sliders_num_columns']
        if 'sliders_timeout_seconds' in self.session.config:
            self.timeout_seconds = self.session.config['sliders_timeout_seconds']

        for p in self.get_players():
            p.prepare_sliders(num=self.num_sliders, min=0, max=100)

class Group(BaseGroup):
    def set_payoffs(self,):
        pass

class BaseSlider(Model):

    class Meta:
        abstract = True

    minimum = models.IntegerField(initial=0)
    maximum = models.IntegerField(initial=100)

    start_pos = models.IntegerField()
    end_pos = models.IntegerField()

    touched = models.BooleanField(initial=False)
    centered = models.BooleanField(initial=False)


    def set_starting_pos(self):
        self.start_pos = randint(self.minimum, self.maximum)
        while self.start_pos == (self.maximum - self.minimum) / 2:
            self.start_pos = randint(self.minimum, self.maximum)

    def distance_from_center(self):
        return abs((self.minimum + self.maximum)/2 - int(self.end_pos))

    def is_centered(self):
        self.centered = self.distance_from_center() == 0
        return self.centered


class SliderPlayer(BasePlayer):

    class Meta:
        abstract = True

    centered_sliders = models.PositiveIntegerField()
    num_sliders = models.PositiveIntegerField()
    slider_min = models.IntegerField()
    slider_max = models.IntegerField()

    def prepare_sliders(self, num=50, min=0, max=100):
        self.num_sliders = num
        self.slider_min = min
        self.slider_max = max
        for _ in range(self.num_sliders):
            slider = self.slider_set.create()
            slider.minimum = self.slider_min
            slider.maximum = self.slider_max
            slider.set_starting_pos()
            slider.save()

    def count_centered_sliders(self):
        sum_of_centered = 0
        for s in self.slider_set.all():
            if s.touched and s.centered:
                sum_of_centered += 1
        self.centered_sliders = sum_of_centered
        # self.save()


class Player(SliderPlayer):
    pass


class Slider(BaseSlider):
    player = ForeignKey(Player, on_delete=models.CASCADE)
