# -*- coding: utf-8 -*-
from __future__ import division
from . import models
from ._builtin import Page, WaitPage
from .models import Constants
import decimal
# from .models import Slider
from django.forms import modelformset_factory
from math import ceil
from random import randint


# page_sequence = [Training,]
class SliderTaskPage(Page):

    # def get_timeout_seconds(self):
    #     return self.subsession.timeout_seconds

    # template_name = "slider_task/SliderTaskPage.html"

    def is_displayed(self):
        if 'effort_variant' in self.session.config and self.session.config['effort_variant']!='sliders':
            return False
        else:
            return True

    def vars_for_template(self):

        SliderFormSet = modelformset_factory(models.Slider, fields=('end_pos', 'touched'), extra=0)

        def _chunks(l, n):
            """Yield successive n-sized chunks from l."""
            for i in range(0, len(l), n):
                yield l[i:i + n]


        sliders_query_set = models.Slider.objects.filter(player__exact=self.player)
        # assert len(sliders_query_set) == Constants.num_sliders

        slider_formset = SliderFormSet(queryset=sliders_query_set)

        # starting_values = [s.start_pos for s in sliders_query_set]
        # min_values = [s.minimum for s in sliders_query_set]
        # max_values = [s.maximum for s in sliders_query_set]
        # offsets = [randint(0, 10) for _ in sliders_query_set]

        starting_values = []
        min_values = []
        max_values = []
        offsets = []
        for s in sliders_query_set:
            starting_values.append(s.start_pos)
            min_values.append(s.minimum)
            max_values.append(s.maximum)
            offsets.append(randint(0, 10))



            if self.subsession.num_slider_columns > 0:
                slider_columns = self.subsession.num_slider_columns
            else:
                slider_columns = 1

        chunk_size = ceil(self.player.num_sliders / slider_columns)

        return {
            'slider_formset': slider_formset,
            'slider_values_and_forms': list(_chunks(list(zip(offsets, min_values, max_values, starting_values, slider_formset.forms)), chunk_size)),
            'slider_columns': slider_columns
        }

    def before_next_page(self):
        submitted_data = self.form.data
        slider_objs_by_id = {slider.pk: slider for slider in self.player.slider_set.all()}
        assert len(slider_objs_by_id) == self.player.num_sliders

        for i in range(self.player.num_sliders):
            input_prefix = 'form-%d-' % i
            print("submitted_data="+str(submitted_data)+", looking for "+str(input_prefix+'id'))
            slider_id = int(submitted_data[input_prefix + 'id'])
            end_pos = submitted_data[input_prefix + 'end_pos']
            touched = submitted_data[input_prefix + 'touched']

            slider = slider_objs_by_id[slider_id]
            slider.end_pos = int(end_pos)
            slider.touched = True if touched == "True" else False
            slider.save()

            slider.is_centered()
            slider.save()

        self.player.count_centered_sliders()

class Results(Page):
    form_model='player'
    form_fields=[]

    def is_displayed(self):
        if 'effort_variant' in self.session.config and self.session.config['effort_variant']!='sliders':
            return False
        else:
            return True

class ResultsWait(WaitPage):
    wait_for_all_groups = True

    def is_displayed(self):
        if 'effort_variant' in self.session.config and self.session.config['effort_variant']!='sliders':
            return False
        else:
            return True

    def after_all_players_arrive(self):
        for group in self.subsession.get_groups():
            for player in group.get_players():
                print("adding " + '{}-centered_sliders'.format(player.participant.id_in_session) + " to self.session.vars")
                self.session.vars['{}-centered_sliders'.format(player.participant.id_in_session)] = player.centered_sliders
                print("inside slider_app, self.session.vars=" + str(self.session.vars))

class Wait(Page):
    form_model = 'player'
    form_fields = []

    def is_displayed(self):
        if 'effort_variant' in self.session.config and self.session.config['effort_variant']!='sliders':
            return False
        else:
            return True

class Sliders(SliderTaskPage):
    Constants = Constants
    Slider = models.Slider
    # ...
page_sequence = [
    SliderTaskPage, ResultsWait, Results, Wait,
]