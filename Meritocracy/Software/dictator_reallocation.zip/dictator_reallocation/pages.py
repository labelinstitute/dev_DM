from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants


class Dictator(Page):
    form_model = 'player'
    form_fields = ['reallocation_amount',]

    def vars_for_template(self):
            print("previous allocation: "+str(self.session.vars['{}-first_dictator_move'.format(self.player.participant.id_in_session)]))
            self.player.reallocation_amount = self.session.vars.get('{}-first_dictator_move'.format(self.player.participant.id_in_session),1)
            self.player.save()

    def before_next_page(self):
        pass

class ResultsWaitPage(WaitPage):

    def after_all_players_arrive(self):
        for player in self.group.get_players():
            player.store_values()

class Wait(Page):
    form_model="player"
    form_fields=[]

page_sequence = [
    Dictator,
    ResultsWaitPage,
    Wait,
]
