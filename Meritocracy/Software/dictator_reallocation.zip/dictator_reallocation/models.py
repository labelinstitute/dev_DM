from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)


author = 'ccrabbe@gmail.com'

doc = """
A visual implementation of a dictator game, meant to be run in a session with the slider_training app
"""


class Constants(BaseConstants):
    name_in_url = 'tpdr'
    players_per_group = None
    num_rounds = 1


class Subsession(BaseSubsession):
    starting_allocation = models.StringField()

    def creating_session(self):
        if 'dictator_starting_allocation' in self.session.config:
            self.starting_allocation = self.session.config['dictator_starting_allocation']

class Group(BaseGroup):
    pass


class Player(BasePlayer):
    reallocation_amount = models.IntegerField(initial=0)

    def store_values(self):
        self.session.vars['{}-dictator_reallocation_move'.format(self.participant.id_in_session)] = self.reallocation_amount
