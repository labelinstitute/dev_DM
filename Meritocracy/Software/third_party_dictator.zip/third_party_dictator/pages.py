from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants


class Dictator(Page):
    form_model = 'player'
    form_fields = ['winner_amount',]

    def before_next_page(self):
        pass

class ResultsWaitPage(WaitPage):

    def after_all_players_arrive(self):
        for player in self.group.get_players():
            player.store_values()

class Wait(Page):
    form_model = 'player'
    form_fields = []
    template_name = 'slider_training/Wait.html'

class LWait(Page):
    form_model = 'player'
    form_fields = []
    # template_name = 'slider_training/Wait.html'

    def is_displayed(self):
        if 'effort_variant' in self.session.config and self.session.config['effort_variant'] == 'luck':
            return True
        else:
            return False

page_sequence = [
    Dictator,
    ResultsWaitPage,
    Wait,
    LWait,
]
