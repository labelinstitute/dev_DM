from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)


author = 'ccrabbe@gmail.com'

doc = """
Your app description
"""


class Constants(BaseConstants):
    name_in_url = 'qe'
    players_per_group = None
    num_rounds = 60


class Subsession(BaseSubsession):
    question_timeout_seconds = models.IntegerField()
    num_questions = models.IntegerField()

    def creating_session(self):

        if 'question_timeout_seconds' in self.session.config:
            self.question_timeout_seconds = self.session.config['question_timeout_seconds']
        if 'question_num_questions' in self.session.config:
            self.num_questions = self.session.config['question_num_questions']
        else:
            self.num_questions = 12

        if self.round_number == 1:
            import csv
            import random

            f = open('questions_from_csv/static/questions_from_csv/trivia_excel.csv')
            rows = list(csv.DictReader(f))
            easy = [r for r in rows if r['easy_or_hard']=='Easy']
            hard = [r for r in rows if r['easy_or_hard']=='Hard']
            random.shuffle(easy)
            random.shuffle(hard)
            print("len(easy)=",len(easy),", len(hard)=",len(hard),"self.num_questions/2=",self.num_questions/2)
            self.session.vars['question_rows'] = easy[0:int(self.num_questions/2)]+hard[0:int(self.num_questions/2)]
            print("question_rows=",self.session.vars['question_rows'])

            for p in self.get_players():
                p.participant.vars['num_correct_answers'] = 0



class Group(BaseGroup):
    pass


class Player(BasePlayer):
    answer = models.IntegerField(label="",widget=widgets.RadioSelect())
    answer_correct = models.BooleanField(initial=False)
    question_text = models.StringField()

    def answer_choices(self):
        row = self.session.vars['question_rows'][self.subsession.round_number-1]
        return [[1,row['answer_1']],
                [2,row['answer_2']],
                [3,row['answer_3']],
                [4,row['answer_4']]
            ]


