from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants


class Questions(Page):
    form_model = 'player'
    form_fields = ['answer']

    def get_timeout_seconds(self):
        print("get_timeout_seconds called, subsession.question_timeout_seconds=",self.subsession.question_timeout_seconds)
        return self.subsession.question_timeout_seconds

    def is_displayed(self):
        if 'effort_variant' in self.session.config and self.session.config['effort_variant']!='questions':
            return False
        else:
            return self.round_number <= self.subsession.num_questions

    def vars_for_template(self):
        rval={}
        rows = self.session.vars['question_rows']
        current_row = rows[self.subsession.round_number-1]
        rval['question_text'] = current_row['question_text']
        self.player.question_text = rval['question_text']
        return rval

    def before_next_page(self):
        if not self.timeout_happened:
            rows = self.session.vars['question_rows']
            current_row = rows[self.subsession.round_number-1]
            self.participant.vars['quiz_'+str(self.round_number)+'_answer'] = self.player.answer
            if current_row['correct_answer'] == current_row['answer_'+str(self.player.answer)]:
                self.player.participant.vars['num_correct_answers'] += 1
                self.player.answer_correct = True
                print("round_number=", self.subsession.round_number, ", answer correct! - num_correct=",
                      self.player.participant.vars['num_correct_answers'])
            self.participant.vars['quiz_' + str(self.round_number) + '_answer_correct'] = self.player.answer_correct

class Wait(Page):
    form_model = 'player'
    form_fields = []

    def is_displayed(self):
        if 'effort_variant' in self.session.config and self.session.config['effort_variant'] != 'questions':
            return False
        return self.subsession.round_number == Constants.num_rounds


class StartButton(Page):
    form_model='player'
    form_fields = []

    def is_displayed(self):
        if 'effort_variant' in self.session.config and self.session.config['effort_variant'] != 'questions':
            return False
        return self.round_number == 1

page_sequence = [StartButton,Questions, Wait]
