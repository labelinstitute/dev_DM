from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)
import otree
import random


author = 'ccrabbe@gmail.com'

doc = """
Your app description
"""


class Constants(BaseConstants):
    name_in_url = 'd21fb'
    players_per_group = None
    num_rounds = 1


class Subsession(BaseSubsession):

    def calculate_results(self):
        # print("calculate_results called. self.session.vars="+str(self.session.vars))

        # first calculate whether a plyer is a winner of the slider task or not, and mark their results
        won_tie = {}
        for p in self.get_players():
            competitor = p.get_dictator_competitor()
            p.competing_participant_id = competitor
            if 'num_correct_answers' not in p.participant.vars:
                counts = [5, 2]
                own_count = random.choice(counts)
                counts.remove(own_count)
                other_count = counts[0]
                p.participant.vars['num_correct_answers'] = own_count
                p.session.get_participants()[competitor - 1].vars['num_correct_answers'] = other_count
        for p in self.get_players():
            won_tie['{}'.format(p.participant.id_in_session)] = None
        for p in self.get_players():
            competitor = p.get_dictator_competitor()
            p.competing_participant_id = competitor
            print("p.id_in_session="+str(p.participant.id_in_session)+", competitor="+str(competitor))
            print("p.session.vars="+str(p.session.vars))
            if 'effort_variant' in p.session.config and p.session.config['effort_variant'] == 'sliders':
                own_count = p.session.vars['{}-centered_sliders'.format(p.participant.id_in_session)]
                other_count = p.session.vars['{}-centered_sliders'.format(competitor)]
            elif 'effort_variant' in p.session.config and p.session.config['effort_variant'] == 'questions':
                own_count = p.participant.vars['num_correct_answers']
                other_count = p.session.get_participants()[competitor-1].vars['num_correct_answers']
            elif 'effort_variant' in p.session.config and p.session.config['effort_variant'] == 'luck':
                own_count = p.participant.vars['num_correct_answers']
                other_count = p.session.get_participants()[competitor - 1].vars['num_correct_answers']

            print("own_count="+str(own_count)+", other="+str(other_count))
            if own_count == other_count:
                if won_tie['{}'.format(competitor)] is not None:
                    p.won_competition = not won_tie['{}'.format(competitor)]
                    print("OTHER already listed as having won the tie or not!  p.won_competition="+str(p.won_competition))
                else:
                    p.won_competition = random.choice([True,False])
                    print("random tie breaker!  p.won_competition=" + str(p.won_competition))
                    won_tie['{}'.format(p.participant.id_in_session)] = p.won_competition
                    won_tie['{}'.format(competitor)] = not p.won_competition
            elif own_count > other_count:
                print("WON")
                p.won_competition = True
                won_tie['{}'.format(p.participant.id_in_session)] = p.won_competition
                won_tie['{}'.format(competitor)] = not p.won_competition
            else:
                print("LOST")
                p.won_competition = False
                won_tie['{}'.format(p.participant.id_in_session)] = p.won_competition
                won_tie['{}'.format(competitor)] = not p.won_competition


        # then figure out what each dictator gives their winner and loser, store those in self.session.vars
        participants = self.session.get_participants()
        for p in self.get_players():
            reallocation_move = p.session.vars['{}-dictator_reallocation_move'.format(p.participant.id_in_session)]
            p.reallocation_move = reallocation_move
            if 'dictator_starting_allocation' in self.session.config and self.session.config[
                'dictator_starting_allocation'] == '6,2':
                p.reallocation_four_minus = 0 - reallocation_move
            else:
                p.reallocation_four_minus = 4 - reallocation_move
            p.dictator_move = p.session.vars['{}-first_dictator_move'.format(p.participant.id_in_session)]
            if 'dictator_starting_allocation' in self.session.config and self.session.config[
                'dictator_starting_allocation'] == '6,2':
                p.dictator_four_minus = 0 - p.dictator_move
            else:
                p.dictator_four_minus = 4 - p.dictator_move
            if 'effort_variant' in p.session.config and p.session.config['effort_variant'] == 'sliders':
                p.effort_num_correct = p.session.vars['{}-centered_sliders'.format(p.participant.id_in_session)]
            elif 'effort_variant' in p.session.config and p.session.config['effort_variant'] == 'questions':
                p.effort_num_correct = p.participant.vars['num_correct_answers']
            elif 'effort_variant' in p.session.config and p.session.config['effort_variant'] == 'luck':
                p.effort_num_correct = -1

            print("player p: "+str(p.participant.id_in_session)+" : gives to winner: "+str(reallocation_move))
            others = p.get_dictator_others()
            if others and len(others)==2:
                for o in others:
                    p.session.vars['{}-dictator_id'.format(o)] = p.participant.id_in_session
                if 'effort_variant' in p.session.config and p.session.config['effort_variant'] == 'sliders':
                    o1_count = p.session.vars['{}-centered_sliders'.format(others[0])]
                    o2_count = p.session.vars['{}-centered_sliders'.format(others[1])]
                elif 'effort_variant' in p.session.config and p.session.config['effort_variant'] == 'questions':
                    o1_count = p.session.get_participants()[others[0] - 1].vars['num_correct_answers']
                    o2_count = p.session.get_participants()[others[1] - 1].vars['num_correct_answers']
                elif 'effort_variant' in p.session.config and p.session.config['effort_variant'] == 'luck':
                    o1_count = p.session.get_participants()[others[0] - 1].vars['num_correct_answers']
                    o2_count = p.session.get_participants()[others[1] - 1].vars['num_correct_answers']

                winner_init_amount=3
                loser_init_amount=1
                if 'dictator_starting_allocation' in self.session.config and self.session.config['dictator_starting_allocation']=='6,2':
                    winner_init_amount = 0
                    loser_init_amount = 0
                    if o1_count == o2_count:
                        o1_won_tie = won_tie['{}'.format(others[0])]
                        if o1_won_tie:
                            p.session.vars['{}-received_from_dictator'.format(others[0])] = winner_init_amount + p.reallocation_move
                            p.session.vars['{}-received_from_dictator'.format(others[1])] = (loser_init_amount - p.reallocation_move)
                        else:
                            p.session.vars['{}-received_from_dictator'.format(others[1])] = winner_init_amount + p.reallocation_move
                            p.session.vars['{}-received_from_dictator'.format(others[0])] = (loser_init_amount - p.reallocation_move)
                    elif o1_count > o2_count:
                        p.session.vars['{}-received_from_dictator'.format(others[0])] = winner_init_amount + p.reallocation_move
                        p.session.vars['{}-received_from_dictator'.format(others[1])] = (loser_init_amount-p.reallocation_move)
                    else:
                        p.session.vars['{}-received_from_dictator'.format(others[1])] = winner_init_amount + p.reallocation_move
                        p.session.vars['{}-received_from_dictator'.format(others[0])] = (loser_init_amount-p.reallocation_move)
                    print('setting '+str(others[0])+".received_from_dictator=", p.session.vars['{}-received_from_dictator'.format(others[0])])
                    print('setting '+str(others[1]) + ".received_from_dictator=",p.session.vars['{}-received_from_dictator'.format(others[1])])
                else:
                    winner_init_amount = 3
                    loser_init_amount = 1
                    if o1_count == o2_count:
                        o1_won_tie = won_tie['{}'.format(others[0])]
                        if o1_won_tie:
                            p.session.vars['{}-received_from_dictator'.format(others[0])] = reallocation_move
                            p.session.vars['{}-received_from_dictator'.format(others[1])] = (4 - reallocation_move)
                        else:
                            p.session.vars['{}-received_from_dictator'.format(others[1])] = reallocation_move
                            p.session.vars['{}-received_from_dictator'.format(others[0])] = (4 - reallocation_move)
                    elif o1_count > o2_count:
                        p.session.vars['{}-received_from_dictator'.format(others[0])] = reallocation_move
                        p.session.vars['{}-received_from_dictator'.format(others[1])] = (4 - reallocation_move)
                    else:
                        p.session.vars['{}-received_from_dictator'.format(others[1])] = reallocation_move
                        p.session.vars['{}-received_from_dictator'.format(others[0])] = (4 - reallocation_move)

        # now loop through again and copy over the amount received
        for p in self.get_players():
            p.received_from_dictator = p.session.vars['{}-received_from_dictator'.format(p.participant.id_in_session)]
            print("p.id_in_session="+str(p.participant.id_in_session)+", p.recieved_from_dictator="+str(p.received_from_dictator))
            p.dictator_id = p.session.vars['{}-dictator_id'.format(p.participant.id_in_session)]
            if 'dictator_starting_allocation' in self.session.config and self.session.config['dictator_starting_allocation'] == '6,2':
                winner_init_amount = 6
                loser_init_amount = 2
                if p.won_competition:
                    p.dictator_points = 6 + p.received_from_dictator
                else:
                    p.dictator_points = 2 + p.received_from_dictator
            else:
                if p.won_competition:
                    p.dictator_points = 3 + p.received_from_dictator
                else:
                    p.dictator_points = 1 + p.received_from_dictator

        # now gather the players' centipede winnings (from the different centipede instances
        for p in self.get_players():
            if '{}-c1_total_payoffs'.format(p.participant.id_in_session) in p.session.vars:
                p.c1_points = float(p.session.vars['{}-c1_total_payoffs'.format(p.participant.id_in_session)])
            if '{}-c2_total_payoffs'.format(p.participant.id_in_session) in p.session.vars:
                p.c2_points = float(p.session.vars['{}-c2_total_payoffs'.format(p.participant.id_in_session)])
            if '{}-c3_total_payoffs'.format(p.participant.id_in_session) in p.session.vars:
                p.c3_points = float(p.session.vars['{}-c3_total_payoffs'.format(p.participant.id_in_session)])

        # now set the payoffs
        for p in self.get_players():
            p.payoff = 0
            if p.won_competition:
                if 'dictator_starting_allocation' in self.session.config and self.session.config['dictator_starting_allocation'] == '6,2':
                    p.payoff += 6
                else:
                    p.payoff += 3
            else:
                if 'dictator_starting_allocation' in self.session.config and self.session.config['dictator_starting_allocation'] == '6,2':
                    p.payoff += 2
                else:
                    p.payoff += 1

            p.payoff += p.received_from_dictator

        # put together questionnaires
        for p in self.get_players():
            q_models_module = otree.common.get_models_module('questionnaire')
            players = q_models_module.Player.objects.filter(
                participant=p.participant
            ).order_by('round_number')
            if players:
                print("questionnaire lookup:  players.length="+str(len(players)))
                p.q_how_hard = players[0].how_hard
                p.q_how_well = players[0].how_well

            fq_models_module = otree.common.get_models_module('final_questions_2021')
            players = fq_models_module.Player.objects.filter(
                participant=p.participant
            ).order_by('round_number')
            if players:
                p.fq_gender = players[0].gender
                p.fq_grade = players[0].grade
                p.fq_year = players[0].birth_year
                p.fq_month = players[0].birth_month
                p.fq_day = players[0].birth_day
                p.fq_younger = players[0].younger_siblings
                p.fq_older = players[0].older_siblings
                p.fq_school = players[0].school_topics
                p.fq_bilingual = players[0].bilingual

class Group(BaseGroup):
    pass


class Player(BasePlayer):
    dictator_move = models.IntegerField()
    dictator_four_minus = models.IntegerField()
    reallocation_move = models.IntegerField()
    reallocation_four_minus = models.IntegerField()
    effort_num_correct = models.IntegerField()
    won_competition = models.BooleanField(initial=None)
    competing_participant_id = models.IntegerField()
    dictator_id = models.IntegerField()
    dictator_points = models.IntegerField()
    received_from_dictator = models.IntegerField(initial=None)

    q_how_hard = models.StringField()
    q_how_well = models.StringField()

    fq_gender = models.StringField()
    fq_grade = models.StringField()
    fq_year = models.IntegerField()
    fq_month = models.StringField()
    fq_day = models.IntegerField()
    fq_younger = models.StringField()
    fq_older = models.StringField()
    fq_school = models.StringField()
    fq_bilingual = models.StringField()

    def get_dictator_competitor(self):
        if self.participant.id_in_session % 2 == 0:
            return self.participant.id_in_session - 1
        else:
            return self.participant.id_in_session + 1

    def get_dictator_others(self):
        num_participants = len(self.session.get_participants())
        if self.participant.id_in_session %2 == 1:
            if self.participant.id_in_session != num_participants-1:
                return [self.participant.id_in_session + 2, self.participant.id_in_session+3]
            else:
                return [1,2]
        else:
            return None
