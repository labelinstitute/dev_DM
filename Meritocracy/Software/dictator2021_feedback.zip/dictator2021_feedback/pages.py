from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants


class Feedback(Page):
    form_model = 'player'
    form_fields = []

    def vars_for_template(self):

        # FOR TESTING
        # if self.participant.id_in_session==1:
        #     self.subsession.calculate_results()

        vars = {}
        print("self.player.won_competition="+str(self.player.won_competition))
        if self.player.won_competition:
            vars['trophy_game_result'] = "You won"
            if 'dictator_starting_allocation' in  self.session.config and self.session.config['dictator_starting_allocation'] == '6,2':
                vars['trophy_result_tokens'] = 6
            else:
                vars['trophy_result_tokens'] = 3
        else:
            vars['trophy_game_result'] = "You didn't win"
            if 'dictator_starting_allocation' in self.session.config and self.session.config['dictator_starting_allocation'] == '6,2':
                vars['trophy_result_tokens'] = 2
            else:
                vars['trophy_result_tokens'] = 1

        vars['trophy_received_tokens'] = self.player.received_from_dictator

        total = int(vars['trophy_result_tokens']) + int(vars['trophy_received_tokens'])
        exchanged_total = total*self.session.config['dictator_exchange_rate']

        vars['trophy_total_tokens'] = total
        vars['exchanged_trophy_tokens'] = exchanged_total

        # centi_total = 0
        # if self.player.c1_points:
        #     centi_total += self.player.c1_points
        # if self.player.c2_points:
        #     centi_total += self.player.c2_points
        # if self.player.c3_points:
        #     centi_total += self.player.c3_points
        #
        # vars['centi_points'] = int(centi_total)
        # vars['total_points'] = int(exchanged_total + centi_total)

        return vars

class CalculateResultsWait(WaitPage):
    wait_for_all_groups = True

    def after_all_players_arrive(self):
        self.subsession.calculate_results()

class Wait(Page):
    form_model = 'player'
    form_fields = []

page_sequence = [
    CalculateResultsWait,
    Feedback
]
